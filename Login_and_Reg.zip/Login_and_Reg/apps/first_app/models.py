from __future__ import unicode_literals
from django.db import models
import re
import bcrypt


class UserManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        if len(postData['name']) < 2 and (postData['name'].isalpha() != True):
            errors['name'] = 'First name must be at least 2 characters and only letters'
        if len(postData['user_name']) < 2:
            errors['user_name'] = 'Last name must be at least 3 characters'
        if len(postData['password']) < 8:
            errors['password'] = 'Password must be at least 8 characters'
        if postData['password'] != postData['confirm_password']:
            errors['confirm_password'] = 'Passwords must match'
        if len(User.objects.filter(user_name = postData['user_name'])) > 0:
            errors['user_name'] = 'Email already in use, please log in' 
        return errors

    def login_validator(self, postData):
        errors = {}
        if len(User.objects.filter(email = postData['email'])) < 1:
            errors['wrong_email'] = 'Incorrect email or password' 
        else:
            u = User.objects.get(email=postData['email'])
            if bcrypt.checkpw(postData['password'].encode(), u.password.encode()) != True:
                errors['wrong_password'] = 'Incorrect email or password'
        return errors

class User(models.Model):
    name = models.CharField(max_length=255)
    user_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    date_hired = models.DateField()
    created_at = models.DateTimeField(auto_now_add = True)
    objects = UserManager()

class ItemManager(models.Manager):
    def item_validator(self, postData):
        errors = {}
        if len(postData['item_name']) < 3 :
            errors['item_name'] = 'Item name must be at least 3 characters'
        return errors

class Item (models.Model):
    item_name = models.CharField(max_length=255)
    added_by  = models.CharField(max_length=255)
    date_added = models.DateTimeField(auto_now_add = True)
    user = models.ForeignKey(User, related_name="items")
    objects = ItemManager()



# class YourWishList(models.Model):
#     item_name = models.CharField(max_length=255)
#     User = models.ForeignKey(new_item, related_name="items")
#     added_by  = models.CharField(max_length=255)
#     date_added = models.DateTimeField(auto_now_add = True)
#     action = models.TextField()
    
# class OtherWishList(models.Model):
#     item_name = models.CharField(max_length=255)
#     added_by  = models.CharField(max_length=255)
#     date_added = models.DateTimeField(auto_now_add = True)
#     action = models.TextField()