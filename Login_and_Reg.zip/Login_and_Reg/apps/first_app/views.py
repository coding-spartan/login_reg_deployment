from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages 
from models import *  
import bcrypt


def index(request):
    request.session.clear()
    return render(request, ('first_app/index.html'))


def process(request):
    if request.method == 'POST':
        errors = User.objects.basic_validator(request.POST)
        if len(errors):
            for tag, error in errors.iteritems():
                messages.error(request, error, extra_tags=tag)
            return redirect('/')
        else:
            hash1 = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt())
            request.session['name'] = request.POST['name']
            User.objects.create(name=request.POST['name'], user_name=request.POST['user_name'], password=hash1)       
            # u = User.objects.get(user_name=request.POST['user_name'])
            # request.session['id'] = u.id
            return redirect('first_app/wishlist')

def login(request):
    if request.method == 'POST':
        errors = User.objects.login_validator(request.POST)
        if len(errors):
            for tag, error in errors.iteritems():
                messages.error(request, error, extra_tags=tag)
            return redirect('/')
        else:
            u = User.objects.get(user_name=request.POST['user_name'])
            request.session['id'] = u.id
            request.session['name'] = u.name
            return redirect ('/wishlist')

def create(request):
    if request.method == "POST":
        errors = Item.objects.create_validator(request.POST)
        if len(errors):
            for tag, error in errors.iteritems():
                messages.error(request, error, extra_tags=tag)
            return redirect('/')
    else:
 	    Item.objects.create(item_name=request.POST['item_name'], added_by=request.session['name'])
 	    request.session['id'] = User.objects.last().id
 	    return redirect('/wishlist', id=request.session['id'])

def wishlist(request):
    return redirect(request, 'first_app/wishlist.html')

# def iteminfo

# def remove

# def delete